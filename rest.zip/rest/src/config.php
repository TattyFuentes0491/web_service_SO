<?php

$db = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'db' => 'blog' //Cambiar al nombre de tu base de datos
];

?>
